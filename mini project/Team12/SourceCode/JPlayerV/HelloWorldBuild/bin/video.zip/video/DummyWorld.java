package video;


import java.awt.EventQueue;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

public class DummyWorld {
	/**
	 * Launch the application.
	 * @throws UnsupportedEncodingException 
	 * @throws FileNotFoundException 
	 */
	//import org.apache.commons.httpclients.*;
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					//HelloWorldBuild window = new HelloWorldBuild();
					//window.frmJplayer.setVisible(true);
					System.out.println("this is HelloWorldBuild");
					//String l = window.sim2tradLyrics(window.searchLrcFile("可惜不是你"));
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}
		});
		
}
}