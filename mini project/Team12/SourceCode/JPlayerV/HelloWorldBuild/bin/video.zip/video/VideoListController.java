package video;
import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class VideoListController {

	private static JTable clipList = null;
        private static VideoPlaylist clipPlaylist = null;
	
	public static File getFileFullPath(JFileChooser fc){
		File file = null;
		String filepath = "";
		// open file chooser
		int result = fc.showOpenDialog(null);
		if( result == JFileChooser.APPROVE_OPTION) {
			file = fc.getSelectedFile();
			filepath = file.getAbsolutePath();
			System.out.println("filepath: " + file.getAbsolutePath());
		}
		return file;
	}
	
	public static void addClip(JTable table, JFileChooser fc, VideoPlaylist playlist, String keyword) {
		File file;
		String filepath;
		int index;
		

//		file = getFileFullPath(fc);
		if(keyword==null){
			System.out.println("no song selected");
			return;
		}else{
//			filepath = file.getAbsolutePath();
		}
		try {	
			//SoundFile.create(filepath);
			index = getSelectedItemIndex(table);
//                        if(filepath.endsWith(".wav"))
			
			playlist.add(keyword);
//                        table.setModel(null);
			table.setModel(redrawTable(table, playlist.list(keyword)));
			if(index == -1) {
				index = 0;
			}
			table.setRowSelectionInterval(index,index);
			
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("err on addSong");
		}
		
	}
	
	public static void removeSong(JTable table, VideoPlaylist playlist, String keyword) {
		if(table.getRowCount() > 0) {
			int index = table.getSelectedRow();
			if(index!=-1) {
				String path = playlist.list(keyword).get(index);
				playlist.remove(path);
				
				table.setModel(redrawTable(table, playlist.list(keyword)));
				
				if(table.getRowCount()>index) {
					// keep same row
					table.setRowSelectionInterval(index, index);
				}else{
					// shift up 1 row if the most bottom row is removed
					if(table.getRowCount()>=1)
						table.setRowSelectionInterval(index-1, index-1);
				}
			}
		}
	}
	
	public static void filtersong(JTable table, VideoPlaylist playlist, String keyword) {
		
		ArrayList<String> list;
		if(keyword.isEmpty()){
			list = playlist.list();
		} else {
			list = playlist.list(keyword);
		}
		table.setModel(redrawTable(table, list));
		
		/*
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<DefaultTableModel>(model);
		table.setRowSorter(sorter);
		
		RowFilter<DefaultTableModel, Object> rf = null;
	    //If current expression doesn't parse, don't update.
	    try {
	        rf = RowFilter.regexFilter(keyword, 0);
	    } catch (java.util.regex.PatternSyntaxException e) {
	        return;
	    }
	    sorter.setRowFilter(rf);
	    */
	}
	
	public static void initSongList(JTable table, VideoPlaylist playlist) {
		clipList = table;
		clipPlaylist = playlist;
		
		table.setModel(redrawTable(table, playlist));
		if(table.getRowCount()>0 && getSelectedItemIndex(table)==-1	) {
			// keep same row
			table.setRowSelectionInterval(0, 0);
		}
	}
	
	public static void refreshSongList() {
		if(clipList!=null && clipPlaylist!=null) {
			clipList.setModel(redrawTable(clipList,clipPlaylist));
		}
	}
	
	private static DefaultTableModel redrawTable(JTable table, VideoPlaylist playlist) {
		/*
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		for(SoundFile s: playlist.list()){
			//String filename = (s.getFilename().isEmpty())? "N/A" : s.getFilename();
			String title = (s.getTitle().isEmpty())? "N/A" : s.getTitle();
			String album = (s.getAlbum().isEmpty())? "N/A" : s.getAlbum();
			
			model.addRow(new Object[]{
				s.getFilename(),
				title,
				album,
				getHumanReadableTime((long) (s.getMicrosecondLength())),
			});
		}
		
		return model;
		*/
		return redrawTable(table, playlist.list());
	}
	private static DefaultTableModel redrawTable(JTable table, ArrayList<String> playlist) {
		DefaultTableModel model = (DefaultTableModel) table.getModel();
		model.setRowCount(0);
		for(String s: playlist){
			//String filename = (s.getFilename().isEmpty())? "N/A" : s.getFilename();
			String title = (s.isEmpty())? "N/A" : s;
//			String album = (s.getAlbum().isEmpty())? "N/A" : s.getAlbum();
			
			model.addRow(new Object[]{
				s,
                                "",
                                "",
                                (long)0,
/*				title,
				album,
				getHumanReadableTime((long) (s.getMicrosecondLength())),*/
			});
		}
		
		return model;
	}
	
	public static String getHumanReadableTime(long t) {
		return String.format("%02d:%02d", 
				TimeUnit.MICROSECONDS.toMinutes(t),
				TimeUnit.MICROSECONDS.toSeconds(t) - TimeUnit.MINUTES.toSeconds(TimeUnit.MICROSECONDS.toMinutes(t))
			);
	}
	
	public static int getSelectedItemIndex(JTable table) {
		return table.getSelectedRow();
	}
	
	public static void readSongInfoFromList(JTable table, JTextArea fullpath, JTextArea filename, JTextField title, JTextField album, VideoPlaylist playlist, String keyword) {
		ArrayList<String> sounds;
		String s;
		int index;
		
		if(keyword.length()>0) {
			sounds = playlist.list(keyword);
		}else{
			sounds = playlist.list();
		}
		
		index = getSelectedItemIndex(table);
		
		if(index >= 0) {
/*			System.out.println(sounds.get(index).getFilename() +";"+
					sounds.get(index).getTitle() +";"+
					sounds.get(index).getAlbum());*/
			filename.setText(sounds.get(index));
/*			title.setText(sounds.get(index).getTitle());
			album.setText(sounds.get(index).getAlbum());
			fullpath.setText(sounds.get(index).getAbsoluteFilename());*/
			//sounds.get(index).getAbsoluteFilename();
		}
	}
	
	public static void writeSongInfoToList(JTable table, JTextArea fullpath, JTextArea filename, JTextField title, JTextField album, VideoPlaylist playlist, String keyword) {
		ArrayList<String> sounds;
		SoundFile s;
		int index;
		
		if(keyword.length()>0) {
			sounds = playlist.list(keyword);
		}else{
			sounds = playlist.list();
		}
		
		index = getSelectedItemIndex(table);
		
		if(index >= 0) {
//			sounds.get(index).setTitle(title.getText());
//			sounds.get(index).setAlbum(album.getText());
			redrawTable(table, sounds);
			
			table.setRowSelectionInterval(index, index);
			
/*			System.out.println(sounds.get(index).getFilename() +";"+
					sounds.get(index).getTitle() +";"+
					sounds.get(index).getAlbum());*/
			
			fullpath.setText("");
			filename.setText("");
			title.setText("");
			album.setText("");
			
		}
	}
}
