package video;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.media.CannotRealizeException;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JSlider;
import javax.swing.JLabel;

import java.awt.Color;

import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.SystemColor;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.JTextPane;

import java.awt.Font;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JProgressBar;
import javax.swing.ScrollPaneConstants;
import javax.swing.JTextArea;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;

//import sun.misc.IOUtils;
import org.apache.commons.io.*;

import java.awt.Dimension;
/*
public class SongListModel extend AbstractTableModel{
	public boolean isCellEditable(int row, int col)
	{
		return false;
	}
}
*/

public class HelloWorldBuild implements ActionListener, ChangeListener, DocumentListener, FocusListener, MouseListener{
	
	
	private JFrame frmJplayer;
	
//	private JTable tableSongList;
        private JTable tableVideoList;
	private JTextField txtSearch;
	public static JButton btnPlay;
	private JButton btnStop;
	private JButton btnPause;
	private JLabel lblSongInfo;
	private JButton btnAdd;
	private JButton btnRemove;
	private JButton btnEdit;
	private JButton btnEditDone;
//	private JSlider sliderVol;
	private JButton btnSearch;
	private JLabel lblLyrics;
//	private JSlider sliderPlayBack;
	
	private JPanel panel;
	private JTextField txtNewTitle;
	private JTextField txtNewAlbum;
	private JTextArea txtaFileName;
	private JTextArea txtaFullpath;
	
	public static JProgressBar progressBar;
	
	private JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
	Database db;
        VideoPlaylist playlist2;
//	SoundPlaylist playlist;
	
	/* event listener */
	
    @Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if(cmd == "play") {
			System.out.println("play");
                        int videoIndex = VideoListController.getSelectedItemIndex(tableVideoList);
                        System.out.println(videoIndex);
                        if(videoIndex == -1) {
                                if(tableVideoList.getRowCount()>0){
                                videoIndex = 0;
                         }
                        else{
                            try {
                                throw new FileNotFoundException();
                            } catch (FileNotFoundException ex) {
                                Logger.getLogger(HelloWorldBuild.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                        }
                        String path = null;
                        path = playlist2.list().get(videoIndex);
                        try {
                            try {
								VideoMain.main(path);
							} catch (ClassNotFoundException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (InstantiationException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (IllegalAccessException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (UnsupportedLookAndFeelException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
                        } catch (CannotRealizeException ex) {
                            Logger.getLogger(HelloWorldBuild.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        //}
//                        btnPlay.setVisible(false);
//                        btnStop.setVisible(true);
		} 
/*		else if(cmd == "pause"){
			System.out.println("pause");
			btnPlay.setVisible(true);
			btnPause.setVisible(false);
			PlayerPanel.player.stop();

		}
		else if(cmd == "stop"){
			System.out.println("stop");
			btnPlay.setVisible(true);
			btnPause.setVisible(false);
                        PlayerPanel.player.stop();
			PlayerFrame.sliderPlayBack.setValue(Math.round(0));
//                        PlayerFrame.setDefaultLookAndFeelDecorated(false);
		}*/
		else if(cmd == "add"){
			System.out.println("add");
                        String path = SongListController.getFileFullPath(fc).getAbsolutePath();
                        System.out.println(path);
/*                        if(path.endsWith("wav"))
			    SongListController.addSong(tableSongList, fc, playlist, txtSearch.getText());
                        else*/
                            VideoListController.addClip(tableVideoList, fc, playlist2, path);
		}
		else if(cmd == "remove")
		{
			System.out.println("remove");
			VideoListController.removeSong(tableVideoList, playlist2, txtSearch.getText());
		}
		else if(cmd == "edit")
		{
			System.out.println("edit");
			if(SongListController.getSelectedItemIndex(tableVideoList) != -1) {
				panel.setVisible(true);
				btnEdit.setVisible(false);
				btnAdd.setVisible(false);
				btnRemove.setVisible(false);
				btnEditDone.setVisible(true);
				VideoListController.readSongInfoFromList(tableVideoList, txtaFullpath, txtaFileName, txtNewTitle, txtNewAlbum, playlist2, txtSearch.getText());
				
			}
		}
		else if(cmd == "done")
		{
			System.out.println("done");
			if(SongListController.getSelectedItemIndex(tableVideoList) != -1) {
				panel.setVisible(false);
				btnEdit.setVisible(true);
				btnAdd.setVisible(true);
				btnRemove.setVisible(true);
				btnEditDone.setVisible(false);
				VideoListController.writeSongInfoToList(tableVideoList, txtaFullpath, txtaFileName, txtNewTitle, txtNewAlbum, playlist2, txtSearch.getText());
				try {
					db.save();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				if(PlayBackController.getSound() != null)
					lblSongInfo.setText(SongInfoController.getSongInfo(PlayBackController.getSound()));
			}
		}
		else if(cmd == "search")
		{
			System.out.println("search");
			System.out.println(txtSearch.getText());
			String keyword = txtSearch.getText();
			VideoListController.filtersong(tableVideoList, playlist2, keyword);
		}
	}
	

	/* DocumentListener */
	public void changedUpdate(DocumentEvent e) {
	    changed(btnSearch);
	}
	public void removeUpdate(DocumentEvent e) {
		changed(btnSearch);
	}
	public void insertUpdate(DocumentEvent e) {
		changed(btnSearch);
	}
	/* FocusListener */
	public void focusGained(FocusEvent e) {
		//System.out.println("focusing...");
		//((JTextField) e.getSource()).setText("");
	}
	public void focusLost(FocusEvent e) {
		//((JTextField) e.getSource()).setText("(Type to Search...)");
	}

	public void changed(JButton btn) {
		if (txtSearch.getText().length()==0){
    	 	//btn.setEnabled(false);
			VideoListController.filtersong(tableVideoList, playlist2, "");

     	}
     	else {
     		//btn.setEnabled(true);
			String keyword = txtSearch.getText();
			VideoListController.filtersong(tableVideoList, playlist2, keyword);
     	}
     
	}
	
	/* MouseListener */
	public void mouseClicked(MouseEvent e) {
		
	}
	public void mouseEntered(MouseEvent e) {
		
	}
	public void mouseExited(MouseEvent e) {
		
	}
	public void mousePressed(MouseEvent e) {
		PlayBackTimerTask.pause();
	}
	public void mouseReleased(MouseEvent e){
		//System.out.println("MouseX = " + e.getX());
		JSlider source = (JSlider) e.getSource();
		if(source.getName()=="sliderPlayBack") {
			
			SoundFile s = PlayBackController.getSound();
			if(s!=null) {
				int position = (int) ((float)source.getValue()/(float)source.getMaximum() * s.getMicrosecondLength());
				System.out.println("onChanged: "+position);
				s.setMicrosecondPosition(position);
			} else {
				source.setValue(0);
			}
		}
		PlayBackTimerTask.resume();
	}
	
	/* init elements */
	private void init(){
		fc.setFileFilter(new FileNameExtensionFilter("wave file (*.wav)", "wav","wmv","(*.wmv)"));
		
		try {
                    	db = Database.load();
			playlist2 = db.getVideo();
			if(playlist2.list().isEmpty()) {
				System.out.println("empty list");
			} else {
				VideoListController.initSongList(tableVideoList, playlist2);
			}
		} catch (Exception e) {
			System.out.println("err on loading db");
			//e.printStackTrace();
		}
		
	}
	/**
	 * Launch the application.
	 * @throws UnsupportedEncodingException 
	 * @throws FileNotFoundException 
	 */
	//import org.apache.commons.httpclients.*;
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					HelloWorldBuild window = new HelloWorldBuild();
					window.frmJplayer.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				
			}
		});
	}
	
	// get trad content using regEx
	private String translateLyrics(String input){
		String tradStr = "";
		String magic = "(.+)/></head>(.*?)</td>";
		Pattern pat = Pattern.compile(magic, Pattern.DOTALL);
		Matcher mat = pat.matcher(input);
		
		if(mat.find()) {
			//System.out.println(mat.group(2));
			tradStr = mat.group(2);
		} else {
			System.out.println("not match");
		}
		return tradStr;
	}
	// httpclient test
	private String sim2tradLyrics(String url){
		String lyrics = "";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost("http://cdict.info/convert/g2b_url.php");
		ArrayList <NameValuePair> nvps = new ArrayList <NameValuePair>();
		nvps.add(new BasicNameValuePair("url", url));//"music.baidu.com/data2/lrc/13839727/13839727.lrc"));
		try {
			httpPost.setEntity(new UrlEncodedFormEntity(nvps));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("httpEntity err");
		}
		
        try {
        	CloseableHttpResponse response2 = httpclient.execute(httpPost);
        	System.out.println("post");
        	System.out.println(response2.getStatusLine());
        	//response2.getEntity().getContent()
        	lyrics = translateLyrics(IOUtils.toString(response2.getEntity().getContent(), "UTF-8"));
			
        	response2.close();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			httpclient.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return lyrics;
	}
	
	// get lrc link
	private String getLrcFile(String input) {
		String site = "http://music.baidu.com/";
		String link = "";
		String magic = "(.*?)down-lrc-btn(.*?)\'href\':\'(.*?)\'";//\\s{\\s\'href\':\'(.*?)\'\\s}";
		Pattern pat = Pattern.compile(magic, Pattern.DOTALL);
		Matcher mat = pat.matcher(input);

		if(mat.find()){
			//System.out.println(mat.group(3));
			link = site+mat.group(3);
		}else{
			System.out.println("not match");
		}
		return link;
	}
	
	//search lrc file
	private String searchLrcFile(String keyword) {
		String link="";
		CloseableHttpClient httpclient = HttpClients.createDefault();
		keyword = keyword.replace(" ", "+");
		String site = "http://music.baidu.com/search/lrc?key=" + keyword;
		HttpGet httpGet = new HttpGet(site);
        try {
			CloseableHttpResponse response1 = httpclient.execute(httpGet);
			System.out.println(response1.getStatusLine());
			String content = IOUtils.toString(response1.getEntity().getContent());
            // do something useful with the response body
            // and ensure it is fully consumed
            //EntityUtils.consume(entity1);
			link = getLrcFile(content);
            response1.close();
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return link;
	}
	/**
	 * Create the application.
	 * @throws InterruptedException 
	 */
	public HelloWorldBuild() throws InterruptedException {
		fc.setDialogTitle("Choose a file to add...");
		draw();
		init();
		addListeners();

		//Thread.sleep(1500);
		//t1.schedule(tt1, 2000);
		//t1.schedule(tt1, 3000);
/*
		int cnt = 1;
		final ActionListener taskPerformer = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                //...Perform a task...
                System.out.println("a task...");
            }
            };
        Timer timer = new Timer( 0 , taskPerformer);
        timer.setRepeats(false);
        timer.start();
        //Thread.sleep(100);

        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
*/		
	}
	/**
	 * resize the icons
	 */
	private ImageIcon makeImageIcon(String path, int width, int height) {
		ImageIcon icon = new ImageIcon(HelloWorldBuild.class.getResource(path));
		if(width<=0 || height <=0){
			return icon;
		}
		Image img = icon.getImage(); 
		BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB); 
		Graphics g = bi.createGraphics(); 
		g.drawImage(img, 0, 0, width, height, null); 
		ImageIcon resizedIcon = new ImageIcon(bi);
		return resizedIcon;
	}
	
	private void addListeners() {
		btnPlay.addActionListener(this);
		btnPlay.setActionCommand("play");
		
		btnPause.addActionListener(this);
		btnPause.setActionCommand("pause");
		
		btnStop.addActionListener(this);
		btnStop.setActionCommand("stop");
		
		btnAdd.addActionListener(this);
		btnAdd.setActionCommand("add");

		btnRemove.addActionListener(this);
		btnRemove.setActionCommand("remove");

		btnEdit.addActionListener(this);
		btnEdit.setActionCommand("edit");
		
		btnEditDone.addActionListener(this);
		btnEditDone.setActionCommand("done");
		
		btnSearch.addActionListener(this);
		btnSearch.setActionCommand("search");
		
		txtSearch.addFocusListener(this);
		
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void draw() {
		//final MediaBtnController mbc = new MediaBtnController();
		
                frmJplayer = new JFrame();
		frmJplayer.setBackground(SystemColor.window);
		//TODO move out windowAdapter
		frmJplayer.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				try {
					db.save();
					System.out.println("db saved");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		frmJplayer.setForeground(Color.WHITE);
		frmJplayer.setTitle("JPlayer");
		frmJplayer.setResizable(false);
		frmJplayer.getContentPane().setBackground(SystemColor.window);
		frmJplayer.setBounds(100, 100, 290, 410);
		frmJplayer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmJplayer.getContentPane().setLayout(null);
		
		//frmJplayer.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Already there
		//frmJplayer.setExtendedState(JFrame.MAXIMIZED_BOTH); //make it maximize
		//frmJplayer.setUndecorated(true); //make the title bar disappear
		
		panel = new JPanel();
		panel.setBorder(new LineBorder(SystemColor.windowBorder));
		panel.setBackground(SystemColor.window);
		panel.setBounds(10, 168, 270, 187);
		panel.setVisible(false);
		frmJplayer.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtNewTitle = new JTextField();
		txtNewTitle.setBounds(104, 46, 134, 28);
		panel.add(txtNewTitle);
		txtNewTitle.setColumns(10);
		
		JLabel lblTitle = new JLabel("Title:");
		lblTitle.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTitle.setBounds(31, 50, 61, 16);
		panel.add(lblTitle);
		
		JLabel lblFilename = new JLabel("Filename:");
		lblFilename.setForeground(SystemColor.inactiveCaptionText);
		lblFilename.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFilename.setBounds(31, 12, 61, 16);
		panel.add(lblFilename);
		
		txtaFileName = new JTextArea();
		txtaFileName.setBackground(SystemColor.window);
		txtaFileName.setEditable(false);
		txtaFileName.setForeground(SystemColor.inactiveCaptionText);
		txtaFileName.setWrapStyleWord(false);
		txtaFileName.setLineWrap(false);
		txtaFileName.setBounds(104, 12, 134, 16);
		panel.add(txtaFileName);
		
		txtNewAlbum = new JTextField();
		txtNewAlbum.setColumns(10);
		txtNewAlbum.setBounds(104, 85, 134, 28);
		panel.add(txtNewAlbum);
		
		JLabel lblAlbum = new JLabel("Album:");
		lblAlbum.setHorizontalAlignment(SwingConstants.RIGHT);
		lblAlbum.setBounds(31, 91, 61, 16);
		panel.add(lblAlbum);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(6, 30, 258, 12);
		panel.add(separator_1);
		
		txtaFullpath = new JTextArea();
		txtaFullpath.setForeground(SystemColor.inactiveCaptionText);
		txtaFullpath.setEditable(false);
		txtaFullpath.setFont(new Font("Lucida Grande", Font.PLAIN, 10));
		txtaFullpath.setBackground(SystemColor.window);
		txtaFullpath.setWrapStyleWord(true);
		txtaFullpath.setLineWrap(true);
		txtaFullpath.setBounds(33, 129, 205, 50);
		panel.add(txtaFullpath);
		
		btnStop = new JButton(makeImageIcon("/iconsNormal/Stop.png",48,48));
//                btnStop = new JButton();
		btnStop.setBounds(62, 90, 55, 55);
		btnStop.setVisible(false);
		frmJplayer.getContentPane().add(btnStop);
		
		btnPlay = new JButton(makeImageIcon("/iconsNormal/Play.png",48,48));
//                btnPlay = new JButton();
		//btnNewButton.setIcon(new ImageIcon(ImageIO.read(HelloWorldBuild.class.getResource("iconsNormal/Play.png"))));

		btnPlay.setBounds(8, 90, 55, 55);
		frmJplayer.getContentPane().add(btnPlay);
		
		lblLyrics = new JLabel("");
		lblLyrics.setForeground(Color.DARK_GRAY);
		lblLyrics.setHorizontalAlignment(SwingConstants.CENTER);
		lblLyrics.setBounds(10, 70, 270, 16);
		frmJplayer.getContentPane().add(lblLyrics);
		
		lblSongInfo = new JLabel("");
		lblSongInfo.setVerticalAlignment(SwingConstants.TOP);
		lblSongInfo.setBackground(SystemColor.window);
		lblSongInfo.setBounds(10, 6, 270, 64);
		frmJplayer.getContentPane().add(lblSongInfo);
		
		
/*		tableSongList = new JTable();
		tableSongList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		TableModel tableModel = new DefaultTableModel(headers,0){
			public boolean isCellEditable(int row, int column)
		    {
		      return false;
		    }
		};
		tableSongList.setModel(tableModel);
		tableSongList.setBackground(Color.WHITE);
		tableSongList.setBounds(10, 443, 270, 129);
		tableSongList.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		frmJplayer.getContentPane().add(tableSongList);*/
                String headers[] = { "Filename" };// "Title", "Album","Length" };
		tableVideoList = new JTable();
		tableVideoList.setShowVerticalLines(false);
		tableVideoList.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		tableVideoList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		TableModel tableModel2 = new DefaultTableModel(headers,0){
			public boolean isCellEditable(int row, int column)
		    {
		      return false;
		    }
		};
		tableVideoList.setModel(tableModel2);
		tableVideoList.setBackground(Color.WHITE);
		tableVideoList.setBounds(12, 220, 270, 129);
		tableVideoList.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		//frmJplayer.getContentPane().add(tableVideoList);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(8, 163, 270, 12);
		frmJplayer.getContentPane().add(separator);
		
		btnAdd = new JButton("+");
		btnAdd.setBounds(166, 359, 40, 25);
		frmJplayer.getContentPane().add(btnAdd);
		
		btnRemove = new JButton("-");
		btnRemove.setBounds(196, 359, 40, 25);
		frmJplayer.getContentPane().add(btnRemove);
		
		btnEdit = new JButton("edit");
		btnEdit.setBounds(230, 359, 55, 25);
		frmJplayer.getContentPane().add(btnEdit);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(8, 170, 236, 28);
		frmJplayer.getContentPane().add(txtSearch);
		txtSearch.setColumns(10);
		
//                btnSearch = new JButton();
		btnSearch = new JButton(makeImageIcon("/iconsNormal/Search.png",20,20));
		txtSearch.getDocument().addDocumentListener(this);
		
		btnSearch.addActionListener(this);
		btnSearch.setHorizontalAlignment(SwingConstants.LEFT);
		btnSearch.setVerticalAlignment(SwingConstants.TOP);
		btnSearch.setBounds(240, 170, 40, 28);
		frmJplayer.getContentPane().add(btnSearch);
		
		JScrollPane scrollPane = new JScrollPane(tableVideoList);
		scrollPane.setBounds(10, 200, 270, 156);
		frmJplayer.getContentPane().add(scrollPane);

//		btnPause = new JButton("Pause");
		btnPause = new JButton(makeImageIcon("/iconsNormal/Pause.png",48,48));
		btnPause.setBounds(8, 90, 55, 55);
		frmJplayer.getContentPane().add(btnPause);
		
		
		btnEditDone = new JButton("done");
		btnEditDone.setActionCommand("done");
		btnEditDone.setVisible(false);
		btnEditDone.setBounds(230, 600, 55, 25);
		frmJplayer.getContentPane().add(btnEditDone);
		
		progressBar = new JProgressBar(SwingConstants.HORIZONTAL, 40 , 60);
		progressBar.setBounds(10, 360, 156, 20);
		frmJplayer.getContentPane().add(progressBar);
		

	}

    @Override
    public void stateChanged(ChangeEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
        
}
